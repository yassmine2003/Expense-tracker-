import javax.swing.*;

public class Forgotpassword {
    private JTextField textField1;
    private JButton sendButton;
}

