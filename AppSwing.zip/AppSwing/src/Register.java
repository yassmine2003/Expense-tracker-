import javax.swing.*;

public class Register {
    private JLabel Register;
    private JTextField usernameTextField;
    private JPasswordField passwordPasswordField;
    private JPanel panel1;
    private JSeparator separator1;
    private JButton button1;

    private void createUIComponents() {
        // TODO: place custom component creation code here
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Register();
            }
        });
    }
}
