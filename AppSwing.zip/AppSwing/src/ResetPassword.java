import javax.swing.*;

public class ResetPassword {
    private JButton resetButton;
    private JPasswordField passwordField1;
    private JPasswordField passwordField2;
}
